#!/bin/sh
tarantoolctl rocks install https://luarocks.org/manifests/bluebird75/luaunit-3.2.1-1.rockspec
